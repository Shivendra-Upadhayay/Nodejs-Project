import joi from "joi";
import { joiPasswordExtendCore } from "joi-password";
const joiPassword = joi.extend(joiPasswordExtendCore);

const userSignupInputValidator = async (req, res, next) => {

	const userSchema = joi.object({
		firstName: joi.string().required(),
		lastName: joi.string().required(),
		username: joi.string().alphanum().max(15).required(),
		email: joi.string().email().required(),
		password: joiPassword
			.string()
			.minOfSpecialCharacters(1)
			.minOfLowercase(2)
			.minOfUppercase(2)
			.minOfNumeric(1)
			.noWhiteSpaces()
			.onlyLatinCharacters()
			.doesNotInclude(['password'])
			.required().min(6),
		role: joi.string().valid("developer", "tester").required()
	})

	const { error } = userSchema.validate(req.body, { abortEarly: false })

	if (error) {
		return res.status(400).json({
			success: false,
			message: "Validation Failed !",
			error: error.details.map(detail => detail.message.replace(/"/g, ""))
		})
	}

	next();

}

export {
	userSignupInputValidator
}