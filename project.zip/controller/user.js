import { User } from "../model/user.js";
import mongoose from "mongoose";

const userSignup = async (req, res) => {

	try {
		let { firstName, lastName, username, email, password, role } = req.body;

		const user = await User.findOne({
			$or: [
				{ username },
				{ email }
			]
		})  //checking user already exist

		if (user) {
			return res.status(400).json({
				success: false,
				message: "User already SignedUp!"
			})
		}

		const doc = new User({
			firstName,
			lastName,
			username,
			email,
			password,
			role
		})

		const savedUser = await doc.save();
		const newUser = await User.findOne({ email }).select("-password -createdAt -updatedAt")
		return res.status(201).json({
			success: true,
			message: "User Signup Successfully!",
			newUser
		})
	} catch (error) {

		console.log(error.message)
		return res.status(500).json({
			success: false,
			message: "Getting error while creating user"
		})

	}

}

export {
	userSignup
}




