import express from "express"
import { connectDatabase } from "./config/database.js";
import { Route } from './route/index.js';
const app = express();

const PORT = process.env.PORT || 8000

new Route(app);
app.use(express.json())
connectDatabase() // connecting database
app.listen(PORT, () => {
	console.log(`server is running on ${PORT}`);
})