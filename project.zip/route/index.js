import express from "express"
import userRouter from "./user.js";

const app = express();

// module.exports.routes = function (app) {
// 	app.use("/user/api/v1/", user);

// 	//other routes..
// }

// export {
// 	routes
// }


export class Route {
	constructor() {
		this.allRoute()
	}
	allRoute() {
		console.log("")
		app.use('/api/v1/user', userRouter)
	}
}
