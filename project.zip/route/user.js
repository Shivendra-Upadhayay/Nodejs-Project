import express from "express"
import { userSignupInputValidator } from "../middleware/uservalidation.js"
import { userSignup } from "../controller/user.js";

const userRouter = express.Router();

userRouter.post("/signup", userSignupInputValidator, userSignup);

export default userRouter;